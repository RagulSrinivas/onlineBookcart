import React, { Component } from 'react'

export const DataContext = React.createContext();

export class DataProvider extends Component {

    state = {
        products: [
            {
                "_id": "1",
                "title": "THE IMMORTALS OF MELUHA",
                "src": "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1334659192l/7913305.jpg",
                "description": "Mythology",
                "content": "AMISH",
                "price": 23,
                "colors": ["red", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "2",
                "title": "how to win friends and influence people",
                "src": "https://rukminim1.flixcart.com/image/832/832/kigbjbk0-0/book/i/q/w/how-to-win-friends-influence-people-original-imafy92jfz6k45t4.jpeg?q=70",
                "description": "Motivational",
                "content": "DALE CARNEGIE ",
                "price": 19,
                "colors": ["red", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "3",
                "title":"do epic shit",
                "src": "https://images-na.ssl-images-amazon.com/images/I/41+grDTP2FL.jpg",
                "description": " Non-fiction, Motivational",
                "content": "ANKUR WARIKOO",
                "price": 50,
                "colors": ["lightblue", "white", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "4",
                "title": "who will cry when you Die?",
                "src": 'https://www.cyberkart.in/wp-content/uploads/2020/11/Who-Will-Cry-When-You-Die.jpg',

                "description": "Motivational,self-help",
                "content": " Robin Sharma",
                "price": 15,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "5",
                "title": "A Game of Thrones:A Song of Ice and Fire:",
                "src": "https://images-na.ssl-images-amazon.com/images/I/91dSMhdIzTL.jpg",
                "description": "GEORGE R.R.MARTIN",
                "content": "GEORGE R.R.MARTIN",
                "price": 10,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "6",
                "title":  "Harry Potter and the Philosopher's Stone",
                "src": "https://upload.wikimedia.org/wikipedia/en/6/6b/Harry_Potter_and_the_Philosopher%27s_Stone_Book_Cover.jpg",
                "description": " Fantasy literature",
                "content": " J.K. Rowling",
                "price": 17,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "7",
                "title": "RICH DAD POOR DAD",
                "src": "https://kbimages1-a.akamaihd.net/ddf8d53d-7df5-4560-8fbd-43915f4f6a03/1200/1200/False/rich-dad-poor-dad-24.jpg",
                "description": " Non-fictional,personal finance",
                "content": "ROBERT T.KIYOSAKI",
                "price": 17,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "8",
                "title": "Think like a monk! ",
                "src": "https://m.media-amazon.com/images/P/B07Y5S56DK.01._SCLZZZZZZZ_SX500_.jpg",
                "description": " Self-help,motivational",
                "content": "JAY SHETTY",
                "price": 17,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "9", 
                "title":"How I Taught My Grandmother to Read and Other Stories ", 
                "src": "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1310136461l/264390.jpg",
                "description": " Fiction",
                "content": "Sudha Murthy",
                "price": 17,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            },
            {
                "_id": "10",
                "title": "Grandma's Bag of Stories",
                "src": "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1346145512l/13510813.jpg",
                "description":" Fiction",
                "content":  "Sudha Murty",
                "price": 17,
                "colors": ["orange", "black", "crimson", "teal"],
                "count": 1
            }
        ],
        cart: [],
        total: 0
        
    };

    addCart = (id) =>{
        const {products, cart} = this.state;
        const check = cart.every(item =>{
            return item._id !== id
        })
        if(check){
            const data = products.filter(product =>{
                return product._id === id
            })
            this.setState({cart: [...cart,...data]})
        }else{
            alert("The product has been added to cart.")
        }
    };

    reduction = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item._id === id){
                item.count === 1 ? item.count = 1 : item.count -=1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    increase = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item._id === id){
                item.count += 1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    removeProduct = id =>{
        if(window.confirm("Do you want to delete this product?")){
            const {cart} = this.state;
            cart.forEach((item, index) =>{
                if(item._id === id){
                    cart.splice(index, 1)
                }
            })
            this.setState({cart: cart});
            this.getTotal();
        }
       
    };

    getTotal = ()=>{
        const{cart} = this.state;
        const res = cart.reduce((prev, item) => {
            return prev + (item.price * item.count);
        },0)
        this.setState({total: res})
    };
    
    componentDidUpdate(){
        localStorage.setItem('dataCart', JSON.stringify(this.state.cart))
        localStorage.setItem('dataTotal', JSON.stringify(this.state.total))
    };

    componentDidMount(){
        const dataCart = JSON.parse(localStorage.getItem('dataCart'));
        if(dataCart !== null){
            this.setState({cart: dataCart});
        }
        const dataTotal = JSON.parse(localStorage.getItem('dataTotal'));
        if(dataTotal !== null){
            this.setState({total: dataTotal});
        }
    }
   

    render() {
        const {products, cart,total} = this.state;
        const {addCart,reduction,increase,removeProduct,getTotal} = this;
        return (
            <DataContext.Provider 
            value={{products, addCart, cart, reduction,increase,removeProduct,total,getTotal}}>
                {this.props.children}
            </DataContext.Provider>
        )
    }
}


